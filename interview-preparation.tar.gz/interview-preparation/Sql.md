# SQL

```bash
rupx@dev:~$ docker ps -a
CONTAINER ID   IMAGE     COMMAND   CREATED   STATUS    PORTS     NAMES
rupx@dev:~$ docker volume create rupx-postgres-data
rupx-postgres-data
rupx@dev:~$ docker network create rupx-net
0be9a1b50f63a83173b3eb3670eb410e2e72017a04cfc4b735135b7cb318cb12
rupx@dev:~$ docker run -d \
  --name postgres \
  --network=rupx-net \
  -v rupx-postgres-data:/var/lib/postgresql/data \
  -e POSTGRES_USER=rupx \
  -e POSTGRES_PASSWORD=rupxpassword \
  -e POSTGRES_DB=rupxdatabase \
  -p 5432:5432 \
  postgres:latest
```

```bash
rupx@dev:~$ docker exec -it postgres /bin/bash
root@a13904646c5e:/# psql -U rupx -d rupxdatabase
```


```bash
rupxdatabase=# CREATE TABLE person(id INT, name VARCHAR(50), age INT);
CREATE TABLE
rupxdatabase=# \d
        List of relations
 Schema |  Name  | Type  | Owner 
--------+--------+-------+-------
 public | person | table | rupx
(1 row)

rupxdatabase=# \d person
                      Table "public.person"
 Column |         Type          | Collation | Nullable | Default 
--------+-----------------------+-----------+----------+---------
 id     | integer               |           |          | 
 name   | character varying(50) |           |          | 
 age    | integer               |           |          | 

rupxdatabase=# INSERT INTO person(id, name, age) VALUES(1,'Rupx',30);
INSERT 0 1
rupxdatabase=# INSERT INTO person(id, name, age) VALUES(2,'Ram',20),(3, 'Samy',28),(4,'Joye',35);
INSERT 0 3
rupxdatabase=# select * from person;
 id | name | age 
----+------+-----
  1 | Rupx |  30
  2 | Ram  |  20
  3 | Samy |  28
  4 | Joye |  35
(4 rows)

rupxdatabase=# SELECT name, age FROM person;
 name | age 
------+-----
 Rupx |  30
 Ram  |  20
 Samy |  28
 Joye |  35
(4 rows)

rupxdatabase=# UPDATE person SET age=49 WHERE name='Samy';
UPDATE 1
rupxdatabase=# SELECT * FROM person;
 id | name | age 
----+------+-----
  1 | Rupx |  30
  2 | Ram  |  20
  4 | Joye |  35
  3 | Samy |  49
(4 rows)

rupxdatabase=# DELETE FROM person WHERE age=20;
DELETE 1
rupxdatabase=# SELECT * FROM person;
 id | name | age 
----+------+-----
  1 | Rupx |  30
  4 | Joye |  35
  3 | Samy |  49
(3 rows)

rupxdatabase=# CREATE TABLE employees (id SERIAL PRIMARY KEY, fname VARCHAR(50) NOT NULL, lname VARCHAR(50) NOT NULL, dept VARCHAR(50), salary DECIMAL(10,2) DEFAULT 15800.00, hire_date DATE NOT NULL DEFAULT CURRENT_DATE);
CREATE TABLE
rupxdatabase=# \d employees
                                     Table "public.employees"
  Column   |         Type          | Collation | Nullable |                Default                
-----------+-----------------------+-----------+----------+---------------------------------------
 id        | integer               |           | not null | nextval('employees_id_seq'::regclass)
 fname     | character varying(50) |           | not null | 
 lname     | character varying(50) |           | not null | 
 dept      | character varying(50) |           |          | 
 salary    | numeric(10,2)         |           |          | 15800.00
 hire_date | date                  |           | not null | CURRENT_DATE
Indexes:
    "employees_pkey" PRIMARY KEY, btree (id)

rupxdatabase=# INSERT INTO employees (id, fname, lname, dept, salary, hire_date) VALUES(1, 'Raj', 'Sharma', 'IT', 50000.00, '2020-01-15'),(2, 'Priya', 'Singh',  'HR', 45000.00, '2019-03-22'),(3, 'Arjun', 'Verma',  'IT', 55000.00, '2021-06-01'),(4, 'Suman', 'Patel', 'Finance', 60000.00, '2018-07-30'),(5, 'Kavita', 'Rao', 'HR', 47000.00, '2020-11-10'),(6, 'Amit', 'Gupta',  'Marketing', 52000.00, '2020-09-25'),(7, 'Neha', 'Desai',  'IT', 48000.00, '2019-05-18'),(8, 'Rahul', 'Kumar',  'IT', 53000.00, '2021-02-14'),(9, 'Anjali', 'Mehta',  'Finance', 61000.00, '2018-12-03'),(10, 'Vijay', 'Nair',  'Marketing', 50000.00, '2020-04-19');
INSERT 0 10
rupxdatabase=# SELECT * FROM employees;
 id | fname  | lname  |   dept    |  salary  | hire_date  
----+--------+--------+-----------+----------+------------
  1 | Raj    | Sharma | IT        | 50000.00 | 2020-01-15
  2 | Priya  | Singh  | HR        | 45000.00 | 2019-03-22
  3 | Arjun  | Verma  | IT        | 55000.00 | 2021-06-01
  4 | Suman  | Patel  | Finance   | 60000.00 | 2018-07-30
  5 | Kavita | Rao    | HR        | 47000.00 | 2020-11-10
  6 | Amit   | Gupta  | Marketing | 52000.00 | 2020-09-25
  7 | Neha   | Desai  | IT        | 48000.00 | 2019-05-18
  8 | Rahul  | Kumar  | IT        | 53000.00 | 2021-02-14
  9 | Anjali | Mehta  | Finance   | 61000.00 | 2018-12-03
 10 | Vijay  | Nair   | Marketing | 50000.00 | 2020-04-19
(10 rows)

rupxdatabase=# INSERT INTO employees (fname, lname) VALUES('Rupam','Ganguly');
INSERT 0 1  
rupxdatabase=# SELECT * FROM employees;
 id | fname  |  lname  |   dept    |  salary  | hire_date  
----+--------+---------+-----------+----------+------------
  1 | Raj    | Sharma  | IT        | 50000.00 | 2020-01-15
  2 | Priya  | Singh   | HR        | 45000.00 | 2019-03-22
  3 | Arjun  | Verma   | IT        | 55000.00 | 2021-06-01
  4 | Suman  | Patel   | Finance   | 60000.00 | 2018-07-30
  5 | Kavita | Rao     | HR        | 47000.00 | 2020-11-10
  6 | Amit   | Gupta   | Marketing | 52000.00 | 2020-09-25
  7 | Neha   | Desai   | IT        | 48000.00 | 2019-05-18
  8 | Rahul  | Kumar   | IT        | 53000.00 | 2021-02-14
  9 | Anjali | Mehta   | Finance   | 61000.00 | 2018-12-03
 10 | Vijay  | Nair    | Marketing | 50000.00 | 2020-04-19
 11 | Rupam  | Ganguly |           | 15800.00 | 2025-04-07
(11 rows)

rupxdatabase=# SELECT * FROM employees WHERE dept='HR';
 id | fname  | lname | dept |  salary  | hire_date  
----+--------+-------+------+----------+------------
  2 | Priya  | Singh | HR   | 45000.00 | 2019-03-22
  5 | Kavita | Rao   | HR   | 47000.00 | 2020-11-10
(2 rows)

rupxdatabase=# SELECT * FROM employees WHERE salary >=60000;
 id | fname  | lname |  dept   |  salary  | hire_date  
----+--------+-------+---------+----------+------------
  4 | Suman  | Patel | Finance | 60000.00 | 2018-07-30
  9 | Anjali | Mehta | Finance | 61000.00 | 2018-12-03
(2 rows)

rupxdatabase=# SELECT * FROM employees WHERE dept='IT' OR dept='HR';
 id | fname  | lname  | dept |  salary  | hire_date  
----+--------+--------+------+----------+------------
  1 | Raj    | Sharma | IT   | 50000.00 | 2020-01-15
  2 | Priya  | Singh  | HR   | 45000.00 | 2019-03-22
  3 | Arjun  | Verma  | IT   | 55000.00 | 2021-06-01
  5 | Kavita | Rao    | HR   | 47000.00 | 2020-11-10
  7 | Neha   | Desai  | IT   | 48000.00 | 2019-05-18
  8 | Rahul  | Kumar  | IT   | 53000.00 | 2021-02-14
(6 rows)

rupxdatabase=# SELECT * FROM employees WHERE dept='IT' AND salary>50000;
 id | fname | lname | dept |  salary  | hire_date  
----+-------+-------+------+----------+------------
  3 | Arjun | Verma | IT   | 55000.00 | 2021-06-01
  8 | Rahul | Kumar | IT   | 53000.00 | 2021-02-14
(2 rows)

rupxdatabase=# SELECT * FROM employees WHERE dept NOT IN ('HR','IT');
 id | fname  | lname |   dept    |  salary  | hire_date  
----+--------+-------+-----------+----------+------------
  4 | Suman  | Patel | Finance   | 60000.00 | 2018-07-30
  6 | Amit   | Gupta | Marketing | 52000.00 | 2020-09-25
  9 | Anjali | Mehta | Finance   | 61000.00 | 2018-12-03
 10 | Vijay  | Nair  | Marketing | 50000.00 | 2020-04-19
(4 rows)

rupxdatabase=# SELECT * FROM employees WHERE id BETWEEN 5 AND 8;
 id | fname  | lname |   dept    |  salary  | hire_date  
----+--------+-------+-----------+----------+------------
  5 | Kavita | Rao   | HR        | 47000.00 | 2020-11-10
  6 | Amit   | Gupta | Marketing | 52000.00 | 2020-09-25
  7 | Neha   | Desai | IT        | 48000.00 | 2019-05-18
  8 | Rahul  | Kumar | IT        | 53000.00 | 2021-02-14
(4 rows)

rupxdatabase=# SELECT DISTINCT dept FROM employees;
   dept    
-----------
 
 Marketing
 Finance
 IT
 HR
(5 rows)

rupxdatabase=# SELECT * FROM employees ORDER BY fname asc;
 id | fname  |  lname  |   dept    |  salary  | hire_date  
----+--------+---------+-----------+----------+------------
  6 | Amit   | Gupta   | Marketing | 52000.00 | 2020-09-25
  9 | Anjali | Mehta   | Finance   | 61000.00 | 2018-12-03
  3 | Arjun  | Verma   | IT        | 55000.00 | 2021-06-01
  5 | Kavita | Rao     | HR        | 47000.00 | 2020-11-10
  7 | Neha   | Desai   | IT        | 48000.00 | 2019-05-18
  2 | Priya  | Singh   | HR        | 45000.00 | 2019-03-22
  8 | Rahul  | Kumar   | IT        | 53000.00 | 2021-02-14
  1 | Raj    | Sharma  | IT        | 50000.00 | 2020-01-15
 11 | Rupam  | Ganguly |           | 15800.00 | 2025-04-07
  4 | Suman  | Patel   | Finance   | 60000.00 | 2018-07-30
 10 | Vijay  | Nair    | Marketing | 50000.00 | 2020-04-19
(11 rows)

rupxdatabase=# SELECT fname FROM employees ORDER BY fname desc;
 fname  
--------
 Vijay
 Suman
 Rupam
 Raj
 Rahul
 Priya
 Neha
 Kavita
 Arjun
 Anjali
 Amit
(11 rows)

rupxdatabase=# 





```